/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.google.zxing.NotFoundException;
import com.google.zxing.WriterException;
import static com.google.zxing.client.j2se.MatrixToImageWriter.toBufferedImage;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.prefs.Preferences;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;

/**
 * FXML Controller class
 *
 * @author Kenway
 */
public class QR_Controller implements Initializable {

    @FXML
    private ImageView QRView;
    @FXML
    private TextField Text;
    private FileChooser fileChooser;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        fileChooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("ِQR Image (*.png)", "*.png");
        fileChooser.getExtensionFilters().add(extFilter);
    }

    @FXML
    private void GenerateQR(ActionEvent event) throws Exception {
        if (!Text.getText().isEmpty()) {
            QRView.setImage(QRCode.create(Text.getText()));
        }

    }

    @FXML
    private void ReadQR(ActionEvent event) throws IOException, FileNotFoundException, NotFoundException {
        File file = fileChooser.showOpenDialog(Launcher.stage);
        String path = file.getPath();
        String QRTEXT = QRCode.read(path);
        Text.setText(QRTEXT);

        BufferedImage read = ImageIO.read(file);
        QRView.setImage(SwingFXUtils.toFXImage(read, null));

    }

    @FXML
    private void SaveQR(ActionEvent event) throws IOException, UnsupportedEncodingException, WriterException {
        try {
            if (QRView.getImage() == null) {

            } else {
                BufferedImage bImage = SwingFXUtils.fromFXImage(QRView.getImage(), null);
                fileChooser.setInitialFileName("QR_Code");
                File file = fileChooser.showSaveDialog(Launcher.stage);
                ImageIO.write(bImage, "png", file);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

    }

}
