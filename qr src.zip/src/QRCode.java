
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.oned.EAN13Writer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import static javafx.scene.input.KeyCode.R;
import javax.imageio.ImageIO;

public class QRCode {

    static String CharSet = "UTF-8";
    static Map<EncodeHintType, ErrorCorrectionLevel> HintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();

    public static Image create(String Text) throws UnsupportedEncodingException, IOException, WriterException {

   MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
Map<EncodeHintType, Object> hintMap = new EnumMap<>(EncodeHintType.class);
multiFormatWriter.encode(Text, BarcodeFormat.QR_CODE, 500, 500, hintMap);
hintMap.put(EncodeHintType.CHARACTER_SET, "UTF-8");
hintMap.put(EncodeHintType.MARGIN, 1); /* default = 4 */
hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
  BitMatrix bitMatrix = multiFormatWriter.encode(Text, BarcodeFormat.QR_CODE, 500, 500, hintMap);
       BufferedImage toBufferedImage = MatrixToImageWriter.toBufferedImage(bitMatrix);
        Image toFXImage = SwingFXUtils.toFXImage(toBufferedImage, null);
        return SwingFXUtils.toFXImage(toBufferedImage, null);


    }

    public static String read(String Path) throws FileNotFoundException, IOException, NotFoundException {
        Map<DecodeHintType, ErrorCorrectionLevel> HintMap = new HashMap<DecodeHintType, ErrorCorrectionLevel>();
        HintMap.put(DecodeHintType.TRY_HARDER, ErrorCorrectionLevel.L);
        String ImagePath = Path;
        BinaryBitmap binaryBitmap = new BinaryBitmap(
                new HybridBinarizer(
                        new BufferedImageLuminanceSource(ImageIO.read(new FileInputStream(ImagePath)))));
        Result QrResult = new MultiFormatReader().decode(binaryBitmap, HintMap);
        return QrResult.getText();

    }
    
     public static BufferedImage generateEAN13BarcodeImage(String barcodeText) throws Exception {
    EAN13Writer barcodeWriter = new EAN13Writer();
    BitMatrix bitMatrix = barcodeWriter.encode(barcodeText, BarcodeFormat.EAN_13, 300, 150);
    return MatrixToImageWriter.toBufferedImage(bitMatrix);
}
}
